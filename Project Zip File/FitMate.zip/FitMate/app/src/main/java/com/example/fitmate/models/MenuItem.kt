package com.example.fitmate.models
data class MenuItem(val title: String, val subtitle: String)